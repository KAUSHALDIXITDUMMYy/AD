"use client"

import { useState, useRef, useEffect } from "react"
import { Search, X } from "lucide-react"

interface Message {
  date: string
  sender: string
  text: string
}

const parseMessages = (text: string): Message[] => {
  const lines = text.split("\n")
  const messages: Message[] = []

  for (const line of lines) {
    // Parse format: DD/MM/YYYY, HH:MM - Sender: Message
    const match = line.match(/(\d{2}\/\d{2}\/\d{4}), (\d{2}:\d{2})\s*-\s*(.+?):\s*(.+)/)
    if (match) {
      const [, date, time, sender, text] = match
      messages.push({
        date: `${date} ${time}`,
        sender: sender.trim(),
        text: text.trim(),
      })
    }
  }

  return messages
}

export default function WhatsAppChat() {
  const [searchTerm, setSearchTerm] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [filteredMessages, setFilteredMessages] = useState<Message[]>([])
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  // WhatsApp chat data
  const chatData = `02/06/2025, 12:57 - Messages and calls are end-to-end encrypted. Only people in this chat can read, listen to, or share them. Learn more.
07/06/2025, 22:39 - kaushal Dixit: Avantika ti list send kar na jyat locations ahe
07/06/2025, 22:40 - Singer Mulli: IMG-20250607-WA0016.jpg (file attached)
09/06/2025, 13:43 - Singer Mulli: https://www.booking.com/Share-1RCzHWk
09/06/2025, 13:44 - kaushal Dixit: Which one exactly
09/06/2025, 13:44 - Singer Mulli: IMG-20250609-WA0003.jpg (file attached)
09/06/2025, 13:46 - kaushal Dixit: https://www.booking.com/hotel/in/vip-guest-house-nashik.en-gb.html?label=nasik-ahNGvGcVlQaPTuv9mynx5wSM553333424614%3Apl%3Ata%3Ap1%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atikwd-1740666277427%3Alp9300354%3Ali%3Adem%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YcpDr58xwogABZVEKmVXkOQ-Share-1RCzHWk%401749456779&sid=13dc7077eddd7a806d242942def7b335&aid=376604&ucfs=1&checkin=2025-07-12&checkout=2025-07-14&group_adults=8&no_rooms=2&group_children=0&srpvid=190c3a07793f00f7&srepoch=1749456962&matching_block_id=1217229101_393883020_4_1_0&atlas_src=hp_iw_title
09/06/2025, 13:47 - kaushal Dixit: Just once he bagh ekds
04/07/2025, 14:35 - kaushal Dixit: Awantika mereko link bhej na
04/07/2025, 14:35 - kaushal Dixit: Apne hotel ki
04/07/2025, 14:35 - kaushal Dixit: Ya flat jo bhi he
04/07/2025, 14:36 - Singer Mulli: Nhi bhejungi
04/07/2025, 14:37 - kaushal Dixit: Dekh le fir
04/07/2025, 14:37 - Singer Mulli: https://www.airbnb.co.in/rooms/1235349190899039976?viralityEntryPoint=1&s=76
04/07/2025, 14:37 - kaushal Dixit: Paani se khatra badhega tera
04/07/2025, 14:37 - Singer Mulli: Bhejjj diyaaa Khusshhhh??
04/07/2025, 14:38 - kaushal Dixit: Haa
04/07/2025, 14:38 - kaushal Dixit: 😂😂
04/07/2025, 14:38 - kaushal Dixit: Mujhe late aya
04/07/2025, 14:39 - Singer Mulli: Bhagwan ka keher
04/07/2025, 14:39 - kaushal Dixit: Tereko ek chij batau ?
04/07/2025, 14:39 - Singer Mulli: Kya
04/07/2025, 14:39 - kaushal Dixit: Ya fir warning ki mat jao
04/07/2025, 14:40 - kaushal Dixit: Tereko teherna sachme nahi ata kya bata to
04/07/2025, 14:40 - Singer Mulli: Mat bolooo … mujhe hatyaa karna acchise aata hai Kar dungi
04/07/2025, 14:40 - Singer Mulli: Nhi aata Kyu
04/07/2025, 14:40 - kaushal Dixit: Fir rehne de
04/07/2025, 14:41 - Singer Mulli: Are kyuu kyaa
04/07/2025, 14:41 - kaushal Dixit: Ha matlab atmahatya ki abhi jarurat nahi lekin
04/07/2025, 14:41 - kaushal Dixit: Are kuch nahi
04/07/2025, 14:41 - Singer Mulli: Nhi kuch to tha
04/07/2025, 14:41 - Singer Mulli: Bol rahe ho ya nhi
04/07/2025, 14:42 - kaushal Dixit: Are ha chalo fir milte 11 ko
04/07/2025, 14:42 - Singer Mulli: Kskeooeirhebdcgsns svhsnsbsv
04/07/2025, 14:43 - kaushal Dixit: Sounds like harry Potter spell
04/07/2025, 14:43 - kaushal Dixit: Wait my chairs flying
04/07/2025, 14:43 - Singer Mulli: Ha vahi hai
04/07/2025, 14:43 - kaushal Dixit: Gotta catch it
04/07/2025, 14:43 - kaushal Dixit: Bbyeee
04/07/2025, 14:43 - Singer Mulli: Bye
06/07/2025, 23:49 - kaushal Dixit: Be congratulations btw 🥳
06/07/2025, 23:49 - Singer Mulli: Kyuu
06/07/2025, 23:51 - kaushal Dixit: Pata chal jayega
06/07/2025, 23:52 - Singer Mulli: Bad manners Kaushal Aise kisiko vichlit nhi karte baalak
06/07/2025, 23:53 - kaushal Dixit: Congratulations se vichalit thodi hote he
06/07/2025, 23:53 - Singer Mulli: Mai hoti hu
06/07/2025, 23:53 - Singer Mulli: Kyu congratulations???
06/07/2025, 23:54 - kaushal Dixit: Nice
06/07/2025, 23:54 - kaushal Dixit: Ho fir thodi aur
06/07/2025, 23:55 - Singer Mulli: Kitna time??
06/07/2025, 23:55 - Singer Mulli: Timmer lagake rakhungi
06/07/2025, 23:55 - kaushal Dixit: 5 min
06/07/2025, 23:55 - kaushal Dixit: Upawas khatam hone de mera
06/07/2025, 23:55 - Singer Mulli: Fine
06/07/2025, 23:55 - kaushal Dixit: Fir khana khake batata
06/07/2025, 23:55 - kaushal Dixit: 😂
06/07/2025, 23:56 - Singer Mulli: Waah
06/07/2025, 23:56 - Singer Mulli: Thik hai thik hai
06/07/2025, 23:56 - kaushal Dixit: Yeah
07/07/2025, 00:02 - Singer Mulli: Ho gaye 5 min
07/07/2025, 00:02 - Singer Mulli: Lo batao
07/07/2025, 00:03 - kaushal Dixit: Haa khake batata
07/07/2025, 00:03 - kaushal Dixit: Ata sutat ahe upawas
07/07/2025, 00:03 - Singer Mulli: Chalo ye bhi thik hai
07/07/2025, 00:11 - kaushal Dixit: Yeahh
07/07/2025, 00:12 - kaushal Dixit: So sutla finally
07/07/2025, 00:13 - Singer Mulli: Finally
07/07/2025, 00:14 - Singer Mulli: Bolo ab kya hai
07/07/2025, 00:14 - Singer Mulli: Aisa kya ukhad liya maine
07/07/2025, 00:15 - kaushal Dixit: Tera nahi tha kya upawas
07/07/2025, 00:15 - Singer Mulli: Thaa n
07/07/2025, 00:15 - Singer Mulli: Usal vala
06/07/2025, 00:36 - kaushal Dixit: Hari Darshan ki pyasi sunna
06/07/2025, 00:36 - kaushal Dixit: YouTube se jo satsang ki clip he
06/07/2025, 00:36 - kaushal Dixit: Already he
06/07/2025, 00:36 - Singer Mulli: Ji avashya Prabhuu🙏
06/07/2025, 00:36 - kaushal Dixit: Tathastu
06/07/2025, 00:37 - Singer Mulli: Accha Aisa hai
06/07/2025, 00:37 - Singer Mulli: Galat line me chale gye aap Kala jaadu chod do
06/07/2025, 00:37 - Singer Mulli: Safed jaadu karo
06/07/2025, 00:38 - kaushal Dixit: Yeah but have you seen nila jaadu ?
06/07/2025, 00:39 - Singer Mulli: Ha dekha hai na Dhoop kha raha tha aaj subah
06/07/2025, 00:39 - kaushal Dixit: Yrr joke hi kharab ho gaya mera
06/07/2025, 00:40 - Singer Mulli: Aleleleele
06/07/2025, 00:40 - Singer Mulli: Mujhse pange nhi
07/07/2025, 01:27 - Singer Mulli: I know Kisi din mere pravachan me bulaungi tumhe
07/07/2025, 01:27 - kaushal Dixit: Aur jo maine suna uske 500 😁
07/07/2025, 01:27 - kaushal Dixit: Haa bs uske pahile concert me bulana
07/07/2025, 01:27 - Singer Mulli: To thik hai 500-500 fittus`

  useEffect(() => {
    const parsed = parseMessages(chatData)
    setMessages(parsed)
    setFilteredMessages(parsed)
  }, [])

  useEffect(() => {
    if (searchTerm.trim() === "") {
      setFilteredMessages(messages)
      setSelectedIndex(-1)
    } else {
      const term = searchTerm.toLowerCase()
      const filtered = messages.filter(
        (msg) => msg.text.toLowerCase().includes(term) || msg.sender.toLowerCase().includes(term),
      )
      setFilteredMessages(filtered)
      setSelectedIndex(filtered.length > 0 ? 0 : -1)
    }
  }, [searchTerm, messages])

  useEffect(() => {
    if (selectedIndex >= 0 && selectedIndex < filteredMessages.length) {
      const selectedMessage = filteredMessages[selectedIndex]
      const messageElements = chatContainerRef.current?.querySelectorAll("[data-message-id]")

      messageElements?.forEach((el) => {
        el.classList.remove("bg-yellow-200")
      })

      const targetElement = chatContainerRef.current?.querySelector(`[data-message-id="${selectedIndex}"]`)
      if (targetElement) {
        targetElement.classList.add("bg-yellow-200")
        targetElement.scrollIntoView({ behavior: "smooth", block: "center" })
      }
    }
  }, [selectedIndex, filteredMessages])

  const keywords = ["radha krishna", "congratulations", "love", "happy", "viral", "upawas", "hatyaa"]

  const handleKeywordSearch = (keyword: string) => {
    setSearchTerm(keyword)
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-2xl h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-4 rounded-t-2xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full" />
            <div>
              <h3 className="font-bold">Our Deleted Chats</h3>
              <p className="text-xs text-green-100">Always here ✨</p>
            </div>
          </div>
          <button className="text-white hover:bg-white/20 p-2 rounded-full transition">
            <X size={24} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-4 border-b flex gap-2">
          <div className="flex-1 relative flex items-center bg-gray-100 rounded-full px-4">
            <Search size={20} className="text-gray-400" />
            <input
              type="text"
              placeholder="Search messages..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-transparent border-none outline-none px-3 py-2 text-sm"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm("")} className="text-gray-400 hover:text-gray-600">
                <X size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Keywords */}
        <div className="px-4 py-2 border-b flex flex-wrap gap-2">
          {keywords.map((keyword) => (
            <button
              key={keyword}
              onClick={() => handleKeywordSearch(keyword)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition ${
                searchTerm.toLowerCase() === keyword.toLowerCase()
                  ? "bg-green-600 text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {keyword}
            </button>
          ))}
        </div>

        {/* Chat Messages */}
        <div ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-2">
          {filteredMessages.length > 0 ? (
            filteredMessages.map((msg, idx) => {
              const isKaushal = msg.sender.includes("kaushal")
              return (
                <div
                  key={idx}
                  data-message-id={idx}
                  className={`flex ${isKaushal ? "justify-end" : "justify-start"} transition-colors duration-300`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                      isKaushal
                        ? "bg-green-100 text-gray-900 rounded-br-none"
                        : "bg-white text-gray-900 border border-gray-200 rounded-bl-none"
                    }`}
                  >
                    <p className="text-xs font-semibold text-gray-600 mb-1">{msg.sender}</p>
                    <p className="text-sm break-words">{msg.text}</p>
                    <p className="text-xs text-gray-500 mt-1">{msg.date}</p>
                  </div>
                </div>
              )
            })
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">No messages found</div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Search Navigation */}
        {searchTerm && filteredMessages.length > 0 && (
          <div className="p-3 bg-white border-t flex items-center justify-between">
            <span className="text-sm text-gray-600">
              Result {selectedIndex + 1} of {filteredMessages.length}
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedIndex((prev) => (prev === 0 ? filteredMessages.length - 1 : prev - 1))}
                className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-sm rounded transition"
              >
                ← Previous
              </button>
              <button
                onClick={() => setSelectedIndex((prev) => (prev === filteredMessages.length - 1 ? 0 : prev + 1))}
                className="px-3 py-1 bg-gray-100 hover:bg-gray-200 text-sm rounded transition"
              >
                Next →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
